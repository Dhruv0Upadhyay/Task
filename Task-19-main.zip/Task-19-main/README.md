# Ansible-Role-to-Configure-K8S-Multi-Node-Cluster-over-AWS-Cloud
ARTH-Task-19
